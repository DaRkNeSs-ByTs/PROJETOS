public class Principal {
    public static void main(String[] args) {

        Aluno aluno1 = new Aluno(
            "Edison Travain",
            "Rua das Flores, 123",
            "14 999-9999",
            "EdisonTravain@email.com",
            "2025001"
        );

        aluno1.exibirinformacoes();
    }
}
